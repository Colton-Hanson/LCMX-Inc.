Open index.html (or LoginDark.dc.html) in Edge/Chrome/Brave.
Dark scheme, 16 screens. Keep all files in this folder together.
Dark color palette + font choices are in the included .png.
All names and amounts are sample data for the mockup.
Expenses you add are saved in your own browser until cleared (link at the bottom of the Expense Added page).

'''Main Screens/Pages'''

Login / Register ........ entry and account creation
Home ..................... month summary, recent activity, Add an expense
Groups / Group page ...... your groups, members, events, recent expenses
Create Group / Event ..... set up a group, or a smaller circle inside it
Group Settings ........... group name, type, members
Add Expense .............. enter by hand: who paid, who is in, how to split
Receipt Upload / Review .. scan a receipt, AI itemizes, you check every item
Expense Added ............ confirmation after saving
Balances ................. who you owe, who owes you, settlement history
Budgets .................. monthly category goals, personal or group
Analysis ................. monthly report for a group
Settings ................. account preferences

'''How-to Nav Main Pages'''
(each line = one click or one action; [Screen] = where you land)

1) Login (start here)
 1. Extract the folder, open index.html (or LoginDark.dc.html)
    in Edge / Chrome / Firefox
 2. [Login] click "Create an account"
 3. [Register] this is the sign-up layout
 4. Click "Log in" to go back
 5. [Login] click "Log in"
 6. [Home] you are in; the top menu bar is used in every flow below
 7. To reset the sample data and start over: open [Login] again, or add ?reset=1 to the end of any page address

2) Scan a receipt (uses AI to read and itemize the receipt, simulated in mockup)
 1. [Home] click "Scan a receipt"
 2. Still on Home: keep "Choose a file" selected
 3. Pick a split: Even / Percentage / Custom amount
 4. Click "Continue"
 5. [Receipt Upload] keep "Choose a file" (mock .jpg attached, read by AI)
 6. Click "Check the items"
 7. [Receipt Review] choose who shares each item
 8. Edit Store / Date if needed, then click "Save expense"
 9. [Expense Added] click "View receipt" to see the slip
10. Click "See it in the monthly report"
11. [Analysis] your expense is in the list, click the receipt icon, or click the little arrow on the expense line, then See Receipt.

3) Add an expense by hand
 1. Click "Add expense" on the top menu bar (or [Home] "Add an expense")
 2. [Add Expense] "Enter by hand" is already selected; type Title (and Location, optional)
    - Shift+Enter in Location adds an address line
 3. Type Total, pick Date, Category, Group, Paid by
 4. Pick a split tab: Even / Custom amount / Percentage / By item
    - By item: add each item, its price, and who shares it
 5. Optional: tick "No receipt" to build a receipt slip
 6. Click "Save expense"
 7. [Expense Added] shows what you entered
 8. Click "See it in the monthly report"
 9. [Analysis] expense and totals are updated

4) Analysis (Might separate and move monthly report to a Monthly Report page with menu button shortcut + add more Metrics/Analytics)
 1. Click "Analysis" on the top menu bar
    (or: Groups >> click a group >> "See the October report")
 2. [Analysis] top shows total, your portion, what you still owe
 3. Use the search bar and filters
 4. Click any expense row to open its details
 5. Click the receipt icon (or "See Receipt") to view the slip
 6. Left panel: click "Who owes what still"
 7. Click the underlined "# expenses" next to a name
 8. A pop-up lists every open expense for that person (has search)

5) Balances
 1. Two ways in:
    - Click "Balances" on the top menu bar, or
    - On [Home], click the "Owed to you" or "You owe" box
      (jumps to Balances page on the list type you chose from Home)
 2. Click "Owes you" or "You owe" to switch lists
    (or "Show both" for one combined list)
 3. You owe: click "Pay"
    - Choose full or part >> click "Mark as paid"
    - A "Paid" status now appears
 4. Owes you: click "Mark received" on a line item when someone pays you
    - If you click it before they click "Pay" on their end, it turns
      yellow "Received (manual)" and Settlement history updates
    - Click the yellow "Received (manual)" text again to uncheck it
    - If they "Pay" you while it is marked manual, the system should
      automatically change the line item to the green checkmark "Paid"
      status (not shown in mockup)
 5. See Settlement history on right hand for payments received and paid

6) Groups
 1. Click "Groups" on the top menu bar
 2. Click a group (each group opens its own page)
 3. [Group page] see recent expenses, events, balances, members
 4. Click "See the October report" to jump to Analysis
 5. Click "New event" for expenses only some members share

7) Budgets
 1. Click "Budgets" on the top menu bar
 2. Use the dropdown to switch between Personal and any group's goals.
 3. To Set Goal(s):
	- Move to "Set a goal" panel on right hand side
 	- Select category (Food, Rent, Entertainment, Other)
 	-  Enter amount and who it applies to (if setting for Group)
	-  Click "Save goal" (the goal card updates)
 4. "Your goals this month" panel provides you with progress bars, and list of categorical goals,
     shows spending amounts as individual or as a Group.

8) Settings (profile menu)
 1. Click the profile circle (top right) >> "Settings"
 2. [Settings] Profile: "Upload a photo" and "Save changes"
 3. Password: type your current password, then a new one
    - The checklist shows the rules (8+ characters, 1 capital, 1 symbol)
 4. Click "Change password" (mock: layout only, nothing is saved)
 5. Appearance: click "Light", "Dark" or "System" to preview the colors
    (mock: it only changes this Settings page; the other screens stay dark)
 6. Also on this page: Notifications and Default split ratio
 7. To leave: Click any button on top navigation bar.
 8. To Log Off: Click profile circle >> "Log out" returns to [Login]

'''End of How-to-Nav-Main-Screens'''
